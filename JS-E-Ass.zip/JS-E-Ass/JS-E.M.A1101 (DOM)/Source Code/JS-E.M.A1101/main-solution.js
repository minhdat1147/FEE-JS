const images = ['img1.jpg', 'img2.png', 'img3.png'];
let index = 0;

// Add your code here
const imageContainer = document.querySelector('.img-container');
const backBtn = document.querySelector('.back');
const nextBtn = document.querySelector('.next');

backBtn.addEventListener('click', function() {
  // Add your code here
  index -= 1;
  if (index < 0) {
    index = 0;
  }

  renderImage();
});

nextBtn.addEventListener('click', function() {
  // Add your code here
  index += 1;
  if (index >= images.length) {
    index = images.length - 1;
  }
  renderImage();
});

// Add your code here
function renderImage() {
  imageContainer.innerHTML = `<img src="images/${images[index]}">`;
}

renderImage();