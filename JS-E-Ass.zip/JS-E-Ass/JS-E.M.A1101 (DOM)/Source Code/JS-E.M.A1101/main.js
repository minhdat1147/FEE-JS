const images = ['img1.jpg', 'img2.png', 'img3.png'];
let index = 0;
 
// Add your code here
// Task 1

backBtn.addEventListener('click', function() {
  // Add your code here
  // Task 3.1
});

nextBtn.addEventListener('click', function() {
  // Add your code here
  // Task 3.2
});

// Add your code here
// Task 2